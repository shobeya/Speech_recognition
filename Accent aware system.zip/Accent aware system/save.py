import joblib

# Save the model
joblib.dump(model, "accent_model.pkl")
