import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Step 1: Load Dataset
df = pd.read_csv("accent-mfcc-data-1.csv")

# Step 2: Features & Labels
X = df.drop('language', axis=1)
y = df['language']

# Step 3: Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 4: Train Model
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

# Step 5: Predict
y_pred = clf.predict(X_test)

# Step 6: Evaluation
accuracy = accuracy_score(y_test, y_pred)
report = classification_report(y_test, y_pred)
conf_matrix = confusion_matrix(y_test, y_pred)
labels = sorted(y.unique())

# Step 7: Display Results
print("🎙️ Accents Detected in Dataset:")
print(", ".join(labels))
print("\n✅ Accuracy: {:.2f}%".format(accuracy * 100))
print("\n📊 Classification Report:\n")
print(report)
print("📌 Confusion Matrix:\n")
print(pd.DataFrame(conf_matrix, index=labels, columns=labels))
