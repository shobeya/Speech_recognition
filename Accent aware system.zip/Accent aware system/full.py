import pandas as pd

# Load the CSV file that contains the labels
df = pd.read_csv('accent-mfcc-data-1.csv')

# Example of inspecting the data
print(df.head())
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib

# Load dataset
df = pd.read_csv("accent-mfcc-data-1.csv")

# Features and labels
X = df.drop('language', axis=1)
y = df['language']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

# Save model
joblib.dump(clf, "accent_model.pkl")
print("✅ Model trained and saved as accent_model.pkl")
# train_model.py

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib

# Load the dataset
data = pd.read_csv("accent-mfcc-data-1.csv")

# Feature and label separation
X = data.drop(['language'], axis=1)
y = data['language']

# Encode the labels
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=42)

# Train a Random Forest classifier
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate the model
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Model Accuracy: {accuracy * 100:.2f}%")

# Save the model and label encoder
joblib.dump(model, 'accent_model.pkl')
joblib.dump(label_encoder, 'label_encoder.pkl')
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Step 1: Load Dataset
df = pd.read_csv("accent-mfcc-data-1.csv")

# Step 2: Features & Labels
X = df.drop('language', axis=1)
y = df['language']

# Step 3: Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 4: Train Model
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

# Step 5: Predict
y_pred = clf.predict(X_test)

# Step 6: Evaluation
accuracy = accuracy_score(y_test, y_pred)
report = classification_report(y_test, y_pred)
conf_matrix = confusion_matrix(y_test, y_pred)
labels = sorted(y.unique())

# Step 7: Display Results
print("🎙️ Accents Detected in Dataset:")
print(", ".join(labels))
print("\n✅ Accuracy: {:.2f}%".format(accuracy * 100))
print("\n📊 Classification Report:\n")
print(report)
print("📌 Confusion Matrix:\n")
print(pd.DataFrame(conf_matrix, index=labels, columns=labels))
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import tkinter as tk
from tkinter import messagebox, filedialog

class AccentModelApp:
    def __init__(self, master):
        self.master = master
        master.title("Accent Detection Model")

        self.label = tk.Label(master, text="Accent Detection Model")
        self.label.pack()

        self.load_button = tk.Button(master, text="Load Dataset", command=self.load_dataset)
        self.load_button.pack()

        self.train_button = tk.Button(master, text="Train Model", command=self.train_model, state=tk.DISABLED)
        self.train_button.pack()

        self.predict_button = tk.Button(master, text="Predict", command=self.predict, state=tk.DISABLED)
        self.predict_button.pack()

        self.result_text = tk.Text(master, height=15, width=50)
        self.result_text.pack()

        self.df = None
        self.clf = None

    def load_dataset(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if file_path:
            self.df = pd.read_csv(file_path)
            self.train_button.config(state=tk.NORMAL)
            messagebox.showinfo("Info", "Dataset loaded successfully!")

    def train_model(self):
        if self.df is not None:
            X = self.df.drop('language', axis=1)
            y = self.df['language']
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

            self.clf = RandomForestClassifier(n_estimators=100, random_state=42)
            self.clf.fit(X_train, y_train)

            y_pred = self.clf.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            report = classification_report(y_test, y_pred)
            conf_matrix = confusion_matrix(y_test, y_pred)

            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, f"Accuracy: {accuracy * 100:.2f}%\n\n")
            self.result_text.insert(tk.END, "Classification Report:\n")
            self.result_text.insert(tk.END, report)
            self.result_text.insert(tk.END, "\nConfusion Matrix:\n")
            self.result_text.insert(tk.END, str(conf_matrix))

            self.predict_button.config(state=tk.NORMAL)
            messagebox.showinfo("Info", "Model trained successfully!")

    def predict(self):
        # Here you can implement a method to take user input for prediction
        # For simplicity, we will just show a message
        messagebox.showinfo("Info", "Prediction functionality is not implemented yet.")

if __name__ == "__main__":
    root = tk.Tk()
    app = AccentModelApp(root)
    root.mainloop()
