import streamlit as st
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import joblib

# Load model and label encoder
model = joblib.load("accent_model.pkl")
label_encoder = joblib.load("label_encoder.pkl")

# Load your dataset (CSV with MFCC or acoustic features)
@st.cache_data
def load_data():
    data = pd.read_csv("accent_features.csv")  # Make sure this file is present
    return data

data = load_data()

# Streamlit app title
st.title("Accent Detection System with Visualization")

# --- Data Visualization Section ---
st.header("📊 Data Visualization")

if st.checkbox("Show Raw Data"):
    st.write(data.head())

if st.checkbox("Correlation Heatmap"):
    st.subheader("Feature Correlation Heatmap")
    plt.figure(figsize=(10, 6))
    corr = data.corr()
    sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
    st.pyplot(plt.gcf())

if st.checkbox("Accent Distribution"):
    st.subheader("Accent Class Distribution")
    if "label" in data.columns:
        class_counts = data["label"].value_counts()
        fig, ax = plt.subplots()
        class_counts.plot(kind='bar', ax=ax, color="skyblue")
        plt.xlabel("Accent")
        plt.ylabel("Count")
        plt.title("Accent Label Distribution")
        st.pyplot(fig)
    else:
        st.warning("No 'label' column found in dataset.")

# --- Accent Prediction Section ---
st.header("🎙️ Accent Prediction")

inputs = []
for i in range(1, 13):
    value = st.number_input(f"MFCC Feature X{i}", value=0.0)
    inputs.append(value)

if st.button("Predict Accent"):
    features = np.array([inputs])
    prediction = model.predict(features)
    result = label_encoder.inverse_transform(prediction)
    st.success(f"🎯 Predicted Accent: {result[0]}")
