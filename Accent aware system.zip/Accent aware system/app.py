import streamlit as st
import numpy as np
import joblib
import soundfile as sf
import librosa
import tempfile
import os
import pandas as pd
import matplotlib.pyplot as plt

st.set_page_config(layout="wide")
st.title("Accent Detection System - Diagnostic Version")

# Debug mode
debug_mode = st.sidebar.checkbox("Enable Debug Mode", value=True)

# Load model and encoder with detailed error reporting
try:
    model = joblib.load("accent_model.pkl")
    st.sidebar.success("✅ Model loaded successfully")
    
    # Display model information
    if debug_mode:
        st.sidebar.subheader("Model Information")
        model_type = type(model).__name__
        st.sidebar.write(f"Model Type: {model_type}")
        
        if hasattr(model, 'feature_importances_'):
            st.sidebar.write("Feature Importances Available")
        elif hasattr(model, 'coef_'):
            st.sidebar.write("Model Coefficients Available")
            
        if hasattr(model, 'classes_'):
            st.sidebar.write(f"Model Classes: {model.classes_}")
except Exception as e:
    st.sidebar.error(f"❌ Error loading model: {e}")
    model = None

try:
    label_encoder = joblib.load("label_encoder.pkl")
    st.sidebar.success("✅ Label Encoder loaded successfully")
    
    # Display encoder information
    if debug_mode:
        st.sidebar.subheader("Label Encoder Information")
        st.sidebar.write(f"Classes: {label_encoder.classes_}")
        st.sidebar.write(f"Number of classes: {len(label_encoder.classes_)}")
        class_distribution = {cls: 0 for cls in label_encoder.classes_}
        st.sidebar.write("Class mapping:", {i: cls for i, cls in enumerate(label_encoder.classes_)})
except Exception as e:
    st.sidebar.error(f"❌ Error loading label encoder: {e}")
    label_encoder = None

if model is None or label_encoder is None:
    st.error("Failed to load required models. Check the sidebar for details.")
    st.stop()

# Function to extract features with diagnostic information
def extract_features_diagnostic(audio_path):
    feature_dict = {}
    
    try:
        # Load audio file
        y, sr = librosa.load(audio_path, sr=None)
        feature_dict["duration"] = librosa.get_duration(y=y, sr=sr)
        feature_dict["sample_rate"] = sr
        
        # Extract MFCCs
        mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
        mfcc_mean = np.mean(mfccs, axis=1)
        feature_dict["mfccs"] = mfcc_mean
        
        # Extract spectral centroid
        spectral_centroids = librosa.feature.spectral_centroid(y=y, sr=sr)[0]
        spectral_centroid_mean = np.mean(spectral_centroids)
        feature_dict["spectral_centroid"] = spectral_centroid_mean
        
        # Extract spectral rolloff
        spectral_rolloff = librosa.feature.spectral_rolloff(y=y, sr=sr)[0]
        spectral_rolloff_mean = np.mean(spectral_rolloff)
        feature_dict["spectral_rolloff"] = spectral_rolloff_mean
        
        # Extract zero crossing rate
        zcr = librosa.feature.zero_crossing_rate(y)[0]
        zcr_mean = np.mean(zcr)
        feature_dict["zcr"] = zcr_mean
        
        # Concatenate all features
        all_features = np.hstack([mfcc_mean, spectral_centroid_mean, spectral_rolloff_mean, zcr_mean])
        feature_dict["all_features_raw"] = all_features
        
        # Reshape for prediction (needed for sklearn models)
        features_for_model = all_features.reshape(1, -1)
        
        # Handle feature dimension mismatch
        expected_features = 12  # From your example
        if features_for_model.shape[1] != expected_features:
            if features_for_model.shape[1] > expected_features:
                # Truncate
                features_for_model = features_for_model[:, :expected_features]
                feature_dict["feature_handling"] = f"Truncated from {all_features.shape[0]} to {expected_features}"
            else:
                # Pad
                padding = np.zeros((1, expected_features - features_for_model.shape[1]))
                features_for_model = np.hstack([features_for_model, padding])
                feature_dict["feature_handling"] = f"Padded from {all_features.shape[0]} to {expected_features}"
        
        feature_dict["features_for_model"] = features_for_model
        return feature_dict
    
    except Exception as e:
        st.error(f"Error extracting features: {e}")
        return None

# Display test examples for multiple accents
col1, col2 = st.columns(2)

with col1:
    st.subheader("Audio Input")
    audio_file = st.file_uploader("Upload Audio File", type=["wav", "flac", "mp3"])
    
    if audio_file:
        st.audio(audio_file, format="audio/wav")
        
        # Save the uploaded file to a temporary location
        with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as tmp_file:
            tmp_file.write(audio_file.getvalue())
            temp_filename = tmp_file.name
            
        # Extract features with diagnostics
        features_dict = extract_features_diagnostic(temp_filename)
        
        if features_dict:
            # Make prediction
            try:
                features = features_dict["features_for_model"]
                prediction = model.predict(features)
                prediction_proba = model.predict_proba(features) if hasattr(model, 'predict_proba') else None
                accent_label = label_encoder.inverse_transform(prediction)
                
                # Display prediction
                st.success(f"Predicted Accent: {accent_label[0]}")
                
                if prediction_proba is not None:
                    st.write("Prediction Probabilities:")
                    proba_df = pd.DataFrame({
                        'Accent': label_encoder.classes_,
                        'Probability': prediction_proba[0] * 100
                    })
                    proba_df = proba_df.sort_values('Probability', ascending=False)
                    
                    # Bar chart of probabilities
                    fig, ax = plt.subplots(figsize=(10, 6))
                    ax.barh(proba_df['Accent'], proba_df['Probability'])
                    ax.set_xlabel('Probability (%)')
                    ax.set_ylabel('Accent')
                    ax.set_title('Prediction Probabilities by Accent')
                    plt.tight_layout()
                    st.pyplot(fig)
            except Exception as e:
                st.error(f"Error during prediction: {e}")
            
            # Clean up temporary file
            os.unlink(temp_filename)
            
        # Test feature extraction debug
        if debug_mode and features_dict:
            with st.expander("Feature Extraction Details"):
                st.write("Audio Duration:", features_dict["duration"], "seconds")
                st.write("Sample Rate:", features_dict["sample_rate"], "Hz")
                
                # Plot MFCCs
                fig, ax = plt.subplots(figsize=(10, 4))
                ax.bar(range(len(features_dict["mfccs"])), features_dict["mfccs"])
                ax.set_title("MFCC Features")
                ax.set_xlabel("MFCC Coefficient")
                ax.set_ylabel("Value")
                st.pyplot(fig)
                
                # Show feature values
                st.write("MFCC Values:", features_dict["mfccs"])
                st.write("Spectral Centroid:", features_dict["spectral_centroid"])
                st.write("Spectral Rolloff:", features_dict["spectral_rolloff"])
                st.write("Zero Crossing Rate:", features_dict["zcr"])
                
                # Display final feature vector
                st.write("Final Feature Vector for Model:", features_dict["features_for_model"])
                if "feature_handling" in features_dict:
                    st.warning(features_dict["feature_handling"])

with col2:
    st.subheader("Debug Options")
    
    # Manual feature input for debugging
    st.write("Test with Custom Feature Vector:")
    test_input = np.array([[7.071476, -6.5129, 7.6508, 11.15078, -7.65731, 12.48402,
                           -11.7098, 3.426596, 1.462715, -2.81275, 0.866538, -5.24427]])
    
    # Allow editing of the test vector
    test_input_str = st.text_area("Edit test feature vector (comma-separated values):", 
                              value=", ".join(map(str, test_input[0])),
                              height=100)
    
    try:
        # Parse the input string back to a numpy array
        custom_test_input = np.array([float(x.strip()) for x in test_input_str.split(",")]).reshape(1, -1)
        
        if st.button("Test with Custom Features"):
            try:
                prediction = model.predict(custom_test_input)
                accent_label = label_encoder.inverse_transform(prediction)
                
                st.success(f"Predicted Accent: {accent_label[0]}")
                
                if hasattr(model, 'predict_proba'):
                    proba = model.predict_proba(custom_test_input)[0]
                    proba_df = pd.DataFrame({
                        'Accent': label_encoder.classes_,
                        'Probability': proba * 100
                    })
                    proba_df = proba_df.sort_values('Probability', ascending=False)
                    st.write("Prediction Probabilities:")
                    st.dataframe(proba_df)
            except Exception as e:
                st.error(f"Error during prediction: {e}")
    except Exception as e:
        st.error(f"Error parsing custom input: {e}")
    
    # Model inspection
    if debug_mode:
        with st.expander("Model Inspection"):
            if hasattr(model, 'feature_importances_'):
                importances = model.feature_importances_
                indices = np.argsort(importances)[::-1]
                
                st.write("Feature Importances:")
                
                fig, ax = plt.subplots(figsize=(10, 6))
                ax.bar(range(len(importances)), importances[indices])
                ax.set_xticks(range(len(importances)))
                ax.set_xticklabels([f"Feature {i}" for i in indices], rotation=90)
                ax.set_xlabel("Feature Index")
                ax.set_ylabel("Importance")
                ax.set_title("Feature Importances")
                plt.tight_layout()
                st.pyplot(fig)
            
            elif hasattr(model, 'coef_'):
                if len(model.classes_) == 2:  # Binary classification
                    coefs = model.coef_[0]
                    indices = np.argsort(np.abs(coefs))[::-1]
                    
                    st.write("Model Coefficients (Binary Classification):")
                    
                    fig, ax = plt.subplots(figsize=(10, 6))
                    ax.bar(range(len(coefs)), coefs[indices])
                    ax.set_xticks(range(len(coefs)))
                    ax.set_xticklabels([f"Feature {i}" for i in indices], rotation=90)
                    ax.set_xlabel("Feature Index")
                    ax.set_ylabel("Coefficient Value")
                    ax.set_title("Model Coefficients")
                    plt.tight_layout()
                    st.pyplot(fig)
                else:  # Multi-class
                    st.write("Model Coefficients (Multi-class):")
                    for i, cls in enumerate(model.classes_):
                        st.write(f"Class {cls} ({label_encoder.inverse_transform([cls])[0]}):")
                        coefs = model.coef_[i]
                        st.write(coefs)
            
            # Decision function exploration
            if hasattr(model, 'decision_function'):
                st.write("Model has decision_function capability")
            
            # Display class count
            if hasattr(model, 'classes_'):
                st.write(f"Number of classes in model: {len(model.classes_)}")
                st.write(f"Classes: {model.classes_}")

# Add model analysis and testing tools
st.subheader("Model Analysis")

with st.expander("Class Distribution Analysis"):
    # Generate synthetic data to test the model's behavior
    if st.button("Test Model with Synthetic Data"):
        # Create synthetic data across the feature space
        n_samples = 100
        n_features = 12  # Based on your test input
        
        synthetic_data = np.random.randn(n_samples, n_features) * 5  # Similar scale to your test vector
        
        try:
            # Get predictions
            synthetic_preds = model.predict(synthetic_data)
            synthetic_labels = label_encoder.inverse_transform(synthetic_preds)
            
            # Count predictions by class
            unique_labels, counts = np.unique(synthetic_labels, return_counts=True)
            
            # Display results
            st.write("Synthetic Data Prediction Distribution:")
            results_df = pd.DataFrame({
                'Accent': unique_labels,
                'Count': counts,
                'Percentage': (counts / n_samples) * 100
            }).sort_values('Count', ascending=False)
            
            st.dataframe(results_df)
            
            # Visualize distribution
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.bar(results_df['Accent'], results_df['Percentage'])
            ax.set_xlabel('Accent')
            ax.set_ylabel('Percentage (%)')
            ax.set_title('Distribution of Predictions on Synthetic Data')
            plt.xticks(rotation=45)
            plt.tight_layout()
            st.pyplot(fig)
            
            # Check if model is biased
            if len(unique_labels) < len(label_encoder.classes_):
                st.warning("⚠️ The model didn't predict all available classes with synthetic data.")
                missing = set(label_encoder.classes_) - set(unique_labels)
                st.write(f"Missing predictions for: {missing}")
            
            # Check for strong bias
            if max(counts) > 0.5 * n_samples:
                st.error("❌ The model shows strong bias toward one class!")
                dominant_class = unique_labels[np.argmax(counts)]
                st.write(f"Dominant class: {dominant_class} ({max(counts)} out of {n_samples} samples)")
        except Exception as e:
            st.error(f"Error testing with synthetic data: {e}")

st.subheader("Recommended Next Steps")
recommendations = [
    "Check if your model was properly trained - the strong bias suggests possible training issues",
    "Verify that the feature extraction method matches what was used during training",
    "Try a basic classifier (like RandomForest) with the extracted features to see if they have discriminative power",
    "Consider retraining the model with balanced class distribution",
    "Ensure the model was saved correctly after training"
]

for i, rec in enumerate(recommendations, 1):
    st.write(f"{i}. {rec}")

# Show how to export a new model
with st.expander("Create a Test Model"):
    st.write("If you want to create a simple test model to verify your system works:")
    
    st.code("""
    # Python code to create a test model
    import numpy as np
    import joblib
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.preprocessing import LabelEncoder
    
    # Create synthetic training data
    X_train = np.random.randn(500, 12)  # 500 samples, 12 features
    
    # Create labels with multiple accents
    accent_labels = ['us', 'uk', 'indian', 'australian', 'canadian']
    y_train = np.random.choice(accent_labels, 500)
    
    # Train a simple model
    rf = RandomForestClassifier(n_estimators=50, random_state=42)
    rf.fit(X_train, y_train)
    
    # Create and save label encoder
    le = LabelEncoder()
    le.fit(accent_labels)
    
    # Save model and encoder
    joblib.dump(rf, "accent_model_test.pkl")
    joblib.dump(le, "label_encoder_test.pkl")
    """, language="python")
