import pandas as pd

# Load the CSV file that contains the labels
df = pd.read_csv('accent-mfcc-data-1.csv')

# Example of inspecting the data
print(df.head())
