import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import tkinter as tk
from tkinter import messagebox, filedialog

class AccentModelApp:
    def __init__(self, master):
        self.master = master
        master.title("Accent Detection Model")

        self.label = tk.Label(master, text="Accent Detection Model")
        self.label.pack()

        self.load_button = tk.Button(master, text="Load Dataset", command=self.load_dataset)
        self.load_button.pack()

        self.train_button = tk.Button(master, text="Train Model", command=self.train_model, state=tk.DISABLED)
        self.train_button.pack()

        self.predict_button = tk.Button(master, text="Predict", command=self.predict, state=tk.DISABLED)
        self.predict_button.pack()

        self.result_text = tk.Text(master, height=15, width=50)
        self.result_text.pack()

        self.df = None
        self.clf = None

    def load_dataset(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if file_path:
            self.df = pd.read_csv(file_path)
            self.train_button.config(state=tk.NORMAL)
            messagebox.showinfo("Info", "Dataset loaded successfully!")

    def train_model(self):
        if self.df is not None:
            X = self.df.drop('language', axis=1)
            y = self.df['language']
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

            self.clf = RandomForestClassifier(n_estimators=100, random_state=42)
            self.clf.fit(X_train, y_train)

            y_pred = self.clf.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            report = classification_report(y_test, y_pred)
            conf_matrix = confusion_matrix(y_test, y_pred)

            self.result_text.delete(1.0, tk.END)
            self.result_text.insert(tk.END, f"Accuracy: {accuracy * 100:.2f}%\n\n")
            self.result_text.insert(tk.END, "Classification Report:\n")
            self.result_text.insert(tk.END, report)
            self.result_text.insert(tk.END, "\nConfusion Matrix:\n")
            self.result_text.insert(tk.END, str(conf_matrix))

            self.predict_button.config(state=tk.NORMAL)
            messagebox.showinfo("Info", "Model trained successfully!")

    def predict(self):
        # Here you can implement a method to take user input for prediction
        # For simplicity, we will just show a message
        messagebox.showinfo("Info", "Prediction functionality is not implemented yet.")

if __name__ == "__main__":
    root = tk.Tk()
    app = AccentModelApp(root)
    root.mainloop()
